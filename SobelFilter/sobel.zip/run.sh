#!/bin/bash

echo "Compiling SobelFilter"
g++ -c SobelFilter.cpp common/FreeImage/lib/linux/x86_64/libfreeimage.a -lOpenCL -Icommon/OpenCL/include -Icommon/OpenCL/FreeImage/include -std=c++11 -o SobelFilter.a

echo "Compiling EdgeDetector"
g++ SobelEdgeDetector.cpp SobelFilter.a common/FreeImage/lib/linux/x86_64/libfreeimage.a -lOpenCL -Icommon/OpenCL/include -std=c++11 -o Sobel

./Sobel lena.bmp
./Sobel valve.png
./Sobel bacteria.jpg